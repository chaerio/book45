package com.book45.mapper;

import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.book45.domain.Criteria;
import com.book45.domain.QnaReplyVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class QnaReplyMapperTest {
	
	@Autowired
	private QnaReplyMapper mapper;
	
	@Test
	public void testMapper() {
		log.info(mapper);
	}
	
	@Test
	public void testInsert() {
		IntStream.range(1, 10).forEach(i ->{
			QnaReplyVO qrVo = new QnaReplyVO();
			qrVo.setQNum(2L);
			qrVo.setContent("수정" + i);
			qrVo.setId("admin00" + i);
			
			mapper.insert(qrVo);
		});
	}
	
	@Test
	public void testRead() {
		log.info(mapper.read(2L));
	}
	
	@Test
	public void testDelete() {
		log.info(mapper.delete(1L));
	}
	
	@Test
	public void testUpdate() {
		QnaReplyVO qrVo = new QnaReplyVO();
		qrVo.setNum(2L);
		qrVo.setContent("안녕안녕");
		mapper.update(qrVo);
	}
	
	/*
	 * @Test public void testPaging() { log.info(mapper.getListWithPaging(new
	 * Criteria(), qnumArr[4])); }
	 * 
	 * @Test public void testPaging2() { log.info(mapper.getListWithPaging(new
	 * Criteria(2,5), qnumArr[0])); }
	 */
	
	@Test
	public void testGetCountByQnum() {
		log.info("count ===>" + mapper.getCountByQnum(22L));
	}
}

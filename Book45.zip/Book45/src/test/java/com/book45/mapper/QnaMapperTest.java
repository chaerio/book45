package com.book45.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.book45.domain.Criteria;
import com.book45.domain.NoticeVO;
import com.book45.domain.QnaVO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class QnaMapperTest {
	@Autowired
	QnaMapper mapper;
	
	@Test
	public void testGetList() {
		mapper.getList().forEach(n -> log.info(n));
	}
	
	@Test
	public void testInsert() {
		QnaVO qVo = new QnaVO();
		qVo.setTitle("New Qna");
		qVo.setContent("New Qna글");
		qVo.setId("new member00");
		mapper.insert(qVo);
	}
	
	@Test
	public void testInsertSelectKey() {
		QnaVO qVo = new QnaVO();
		qVo.setTitle("공지글222");
		qVo.setContent("공지게시글2222");
		qVo.setId("member00");
		mapper.insertSelectKey(qVo);
		log.info(qVo);
	}
	
	@Test
	public void testRead() {
		QnaVO qVo = mapper.read(2L);
		log.info(qVo);
	}
	
	@Test
	public void testDelete() {
		log.info(mapper.delete(1L));
	}
	
	@Test
	public void testUpdate() {
		QnaVO qVo = new QnaVO();
		qVo.setNum(2L);
		qVo.setTitle("수정한 질문글입니다.");
		qVo.setContent("수정됨 으라아아아");
		mapper.update(qVo);
		log.info(qVo);
	}
	
	@Test
	public void testGetListWithPaging() {
		Criteria cri = new Criteria();
		cri.setPageNum(3);
		cri.setAmount(10);
		
		List<QnaVO> list = mapper.getListWithPaging(cri);
		
		list.forEach(n -> log.info(n.getNum()));
	}
	
	@Test
	public void testSearch() {
		Criteria cri = new Criteria();
		cri.setKeyword("수정");
		cri.setType("TC");
		
		List<QnaVO> list = mapper.getListWithPaging(cri);
		
		list.forEach(n -> log.info(n));
	}
}

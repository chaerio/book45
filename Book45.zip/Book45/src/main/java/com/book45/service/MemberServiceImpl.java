package com.book45.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book45.domain.Criteria;
import com.book45.domain.MemberVO;
import com.book45.mapper.MemberMapper;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberMapper memberMapper;
	
	@Override
	public void memberJoin(MemberVO member) {
		memberMapper.memberJoin(member);
	}

	@Override
	public int idCheck(String id) throws Exception {
		return memberMapper.idCheck(id);
	}
	
	@Override
	public int nickNameCheck(String nickname) throws Exception {
		return memberMapper.nicknameCheck(nickname);
	}
	
	@Override
	public MemberVO memberLogin(MemberVO member) throws Exception {
		return memberMapper.memberLogin(member);
	}

	@Override
	public MemberVO getMember(String id) {
		return memberMapper.getMember(id);
	}

	@Override
	public int updateMypage(MemberVO member) {
		return memberMapper.updateMypage(member);
	}

	@Override
	public int deleteMember(String id) {
		return memberMapper.deleteMember(id);
	}

	@Override
	public List<MemberVO> getMemberList() {
		return memberMapper.getMemberList();
	}

	@Override
	public int updateByAdmin(MemberVO member) {
		return memberMapper.updateByAdmin(member);
	}

//	@Override
//	public List<OrderDTO> getOrderList(Criteria cri) {
//		return memberMapper.getOrderList(cri);
//	}
//
//	@Override
//	public int getOrderTotal(Criteria cri) {
//		return memberMapper.getOrderTotal(cri);
//	}
}

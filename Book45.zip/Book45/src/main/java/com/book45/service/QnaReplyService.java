package com.book45.service;

import java.util.List;

import com.book45.domain.Criteria;
import com.book45.domain.QnaReplyPageDTO;
import com.book45.domain.QnaReplyVO;

public interface QnaReplyService {
	
	public int register(QnaReplyVO qrVo);
	public QnaReplyVO get(Long num);
	public int modify(QnaReplyVO qrVo);
	public List<QnaReplyVO> getList(Criteria cri, Long qNum);
	public int remove(Long num);
	public QnaReplyPageDTO getListPage(Criteria cri, Long qNum);
}

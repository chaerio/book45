package com.book45.service;

import java.util.List;

import com.book45.domain.BookReviewPageDTO;
import com.book45.domain.BookReviewVO;
import com.book45.domain.Criteria;

public interface BookReviewService {

	public int register(BookReviewVO vo);
	
	public BookReviewVO get(Long num);
	
	public int modify(BookReviewVO vo);
	
	public int remove(Long num); 
	
	public List<BookReviewVO> getList(Criteria cri, Long isbn);
	
	public BookReviewPageDTO getListPage(Criteria cri, Long isbn);
	
	
}

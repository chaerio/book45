package com.book45.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book45.domain.Criteria;
import com.book45.domain.ReplyPageDTO;
import com.book45.domain.ReplyVO;
import com.book45.mapper.BoardMapper;
import com.book45.mapper.ReplyMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class ReplyServiceImpl implements ReplyService {
	
	private ReplyMapper mapper;
	
	private BoardMapper boardMapper;
	
	@Transactional
	@Override
	public int register(ReplyVO vo) {
		
		log.info("register" + vo);
		boardMapper.updateReplyCnt(vo.getBoardNum(), 1);
		return mapper.insert(vo);
	}
	
	@Override
	public ReplyVO get(Long replyNum) {
		
		log.info("get" + replyNum);
		return mapper.read(replyNum);
	}

	@Override
	public int modify(ReplyVO vo) {
		
		log.info("modify" + vo);
		return mapper.update(vo);
	}
	
	@Transactional
	@Override
	public int remove(Long replyNum) {
		
		ReplyVO vo = mapper.read(replyNum);
		log.info("remove" + replyNum);
		boardMapper.updateReplyCnt(vo.getBoardNum(), -1);
		return mapper.delete(replyNum);
	}

	@Override
	public List<ReplyVO> getList(Criteria cri, int boardNum) {
		
		log.info("get reply list of a board : " + boardNum);
		return mapper.getListWithPaging(cri, boardNum);
	}
	
	@Override
	public ReplyPageDTO getListPage(Criteria cri, int boardNum) {
		
		return new ReplyPageDTO(
				mapper.getCountByNum(boardNum),
				mapper.getListWithPaging(cri, boardNum));
	}

}

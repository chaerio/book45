package com.book45.domain;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

@Data
@AllArgsConstructor

public class ReplyPageDTO {
	private int readCount;
	private List<ReplyVO> list;
}

package com.book45.service;

import java.util.List;

import com.book45.domain.OrderCancelDTO;
import com.book45.domain.OrderDTO;
import com.book45.domain.OrderPageItemDTO;

public interface OrderService {
	/* 주문 정보*/
	public List<OrderPageItemDTO> getBooksInfo(List<OrderPageItemDTO> orders);
	
	/* 앨범 주문 정보 */
	public List<OrderPageItemDTO> getAlbumsInfo(List<OrderPageItemDTO> orders);
	
	/* 주문 */
	public void orderBook(OrderDTO ord);
	
	public void orderAlbum(OrderDTO ord);
	
	/* 주문 취소*/
	public void orderCancel(OrderCancelDTO orderCancel);
}

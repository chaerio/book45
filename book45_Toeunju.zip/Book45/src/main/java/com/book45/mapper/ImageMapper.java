package com.book45.mapper;

import java.util.List;

import com.book45.domain.ImageVO;

public interface ImageMapper {
	public List<ImageVO> getImageList(Long isbn);
}

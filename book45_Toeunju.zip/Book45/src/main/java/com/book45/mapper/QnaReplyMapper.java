package com.book45.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.book45.domain.Criteria;
import com.book45.domain.QnaReplyVO;

public interface QnaReplyMapper {
	
	//등록
	public int enrollQnaReply(QnaReplyVO qrVo);

	//페이징
	public List<QnaReplyVO> getQnaReplyList(Criteria cri);

	//총 갯수
	public int getQnaReplyTotal(int qnaNum);	

	//수정
	public int updateQnaReply(QnaReplyVO qrVo);	

	//힌개 정보 수정
	public QnaReplyVO getUpdateQnaReply(int num);

	//삭제
	public int deleteQnaReply(int num);
	
	
//	댓글체크 부분 주석
//	public Integer checkQnaReply(QnaReplyVO qrVo);	
	
//	구버전
//	public int insert(QnaReplyVO qrVo);
//	public QnaReplyVO read(int num);
//	public int delete(int num);
//	public int update(QnaReplyVO qrVo);
//	public List<QnaReplyVO> getListWithPaging(@Param("cri") Criteria cri, @Param("qNum") int qNum);
//	public int getCountByQnum(int qnum);

}

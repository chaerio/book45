package com.book45.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book45.domain.Criteria;
import com.book45.domain.PageDTO;
import com.book45.domain.QnaReplyPageDTO;
import com.book45.domain.QnaReplyVO;
import com.book45.mapper.QnaMapper;
import com.book45.mapper.QnaReplyMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@AllArgsConstructor
@Service
public class QnaReplyServiceImpl implements QnaReplyService {
	
	@Autowired
	private QnaReplyMapper mapper;
	
	@Autowired
	private QnaMapper qnaMapper;

	@Override
	public int enrollQnaReply(QnaReplyVO qrVo) {
		
		log.info("enrollQnaReply" + qrVo);
		//상태 처리를 위한 count 추가
		qnaMapper.updateReplyCnt(qrVo.getQnaNum(), 1);
		
		int result = mapper.enrollQnaReply(qrVo);
		
		return result;
	}
	
	@Override
	public QnaReplyPageDTO qnaReplyList(Criteria cri) {
		
		QnaReplyPageDTO dto = new QnaReplyPageDTO();
		
		dto.setList(mapper.getQnaReplyList(cri));
		dto.setPageInfo(new PageDTO(cri, mapper.getQnaReplyTotal(cri.getQnaNum())));
		
		return dto;
	}	
	
	@Override
	public int updateQnaReply(QnaReplyVO qrVo) {
		
		int result = mapper.updateQnaReply(qrVo); 

		return result;
	}	
	
	@Override
	public QnaReplyVO getUpdateQnaReply(int num) {
		
		return mapper.getUpdateQnaReply(num);
	}	
	
	@Override
	public int deleteQnaReply(QnaReplyVO qrVo) {
		
		int result = mapper.deleteQnaReply(qrVo.getNum()); 
		
		return result;
	}		
	
	
//	댓글체크 부분 주석
//	@Override
//	public String checkQnaReply(QnaReplyVO qrVo) {
//		
//		Integer result = mapper.checkQnaReply(qrVo);
//		
//		if(result == null) {
//			return "0";
//		} else {
//			return "1";
//		}
//		
//	}	
	
	/* 구버전
	 * @Override public int register(QnaReplyVO qrVo) {
	 * 
	 * qnaMapper.updateReplyCnt(qrVo.getQNum(), 1); return mapper.insert(qrVo); }
	 * 
	 * @Override public QnaReplyVO get(int num) { return mapper.read(num); }
	 * 
	 * @Override public int modify(QnaReplyVO qrVo) { return mapper.update(qrVo); }
	 * 
	 * 
	 * @Override public List<QnaReplyVO> getList(Criteria cri, int qNum) { return
	 * mapper.getListWithPaging(cri, qNum); }
	 * 
	 * 
	 * 
	 * @Override public int remove(int num) { QnaReplyVO qrVo = mapper.read(num);
	 * return mapper.delete(num); }
	 * 
	 * @Override public QnaReplyPageDTO getListPage(Criteria cri, int qNum) { return
	 * new QnaReplyPageDTO( mapper.getCountByQnum(qNum),
	 * mapper.getListWithPaging(cri, qNum) ); }
	 */


	
}

package com.book45.domain;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;


/*
CREATE TABLE QNAREPLY (
	NUM NUMBER(10)	PRIMARY KEY,
	QNANUM	NUMBER(10) CONSTRAINT QNAREPLY_QNUM_FK REFERENCES QNA(NUM) ON DELETE CASCADE, -- 원 Q&A 게시글 번호
    ID	VARCHAR2(20)	 CONSTRAINT QNAREPLY_ID_FK REFERENCES MEMBER(id) ON DELETE CASCADE,
	CONTENT	VARCHAR2(4000)	NULL,
	WRITEDATE	DATE	default sysdate
);
create SEQUENCE QNAREPLY_SEQ;

commit;

select * from qnareply;
*/

@Data
public class QnaReplyVO {
	
	private int num;
	private int qnaNum;
	private String id;
	private String content;
	
	@JsonFormat(shape= JsonFormat.Shape.STRING, pattern="yyyy-MM-dd", timezone="Asia/Seoul")
	private Date writeDate;


}

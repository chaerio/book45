package com.book45.domain;

import lombok.Data;

@Data
public class ImageVO {
	private String uploadPath;
	private String uuid;
	private String fileName;
	private Long isbn;
}

package com.book45.domain;

import java.util.Date;

import lombok.Data;

/*
CREATE TABLE QNA (
	QNUM NUMBER(10) PRIMARY KEY not null,
    ID VARCHAR2(20) CONSTRAINT  QNA_ID_FK references member(id) not null,
    TITLE VARCHAR2(1000) null,
    CONTENT VARCHAR2(4000) null,
    WRITEDATE DATE DEFAULT SYSDATE,
    UPDATEDATE DATE DEFAULT SYSDATE,
    SECRET VARCHAR2(20) DEFAULT 'Y', -- Y: 비밀글 활성화  N:비활성화
    replycnt  number(10) DEFAULT 0,
*/
@Data
public class QnaVO {
	
	private int qnum;
	private String id;
	private String title;
	private String content;
	private Date writeDate;
	private Date updateDate;
	private String secret;
	private Boolean replyCnt;	//리플수 : 1 로 제한 == 답변상태 : 0(= 처리중 ) or 1(= 답변완료 )
}

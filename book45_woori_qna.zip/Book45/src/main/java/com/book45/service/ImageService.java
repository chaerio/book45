package com.book45.service;

import java.util.List;

import com.book45.domain.ImageVO;

public interface ImageService {
	public List<ImageVO> getImageList(Long isbn);
	
}

package com.book45.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.book45.domain.Criteria;
import com.book45.domain.QnaVO;
import com.book45.mapper.QnaMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class QnaServiceImpl implements QnaService {

	
	@Autowired
	public QnaMapper mapper;

	@Transactional
	@Override
	public void register(QnaVO qVo) {
		mapper.updateReplyCnt(qVo.getNum(), 1);
		mapper.insertSelectKey(qVo);
		
	}

	@Override
	public QnaVO get(int num) {
		return mapper.read(num);
	} 

	@Override
	public boolean modify(QnaVO qVo) {
		return mapper.update(qVo) == 1 ? true : false;
	}

	@Override
	public boolean remove(int num) {
		return mapper.delete(num);
	}

	@Override
	public List<QnaVO> getList(Criteria cri) {
		return mapper.getListWithPaging(cri);
	}

	@Override
	public int getTotal(Criteria cri) {
		return mapper.getTotalCount(cri);
	}

	//추가!!  
	@Override
	public QnaVO getQnaTitle(int num) {
		return mapper.getQnaTitle(num);
	}
	

}

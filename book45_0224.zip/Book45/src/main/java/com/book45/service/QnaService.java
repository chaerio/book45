package com.book45.service;

import java.util.List;

import com.book45.domain.Criteria;
import com.book45.domain.QnaVO;
import com.book45.domain.ReplyPageDTO;


public interface QnaService {

	public void register(QnaVO qVo);
	
	public QnaVO get(int num);
	
	public boolean modify(QnaVO qVo);
	
	public boolean remove(int num);
	
	public List<QnaVO> getList(Criteria cri);
	
	public int getTotal(Criteria cri);
	
//	추가! Qna title 
	public QnaVO getQnaTitle(int num);
	
	
	
}

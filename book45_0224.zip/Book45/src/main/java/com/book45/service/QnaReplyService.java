package com.book45.service;

import java.util.List;

import com.book45.domain.Criteria;
import com.book45.domain.PageDTO;
import com.book45.domain.QnaReplyPageDTO;
import com.book45.domain.QnaReplyVO;

public interface QnaReplyService {

	//등록
	public int enrollQnaReply(QnaReplyVO qrVo);
//	댓글체크 부분 주석
//	public String checkQnaReply(QnaReplyVO qrVo);	

	//페이징
	public QnaReplyPageDTO qnaReplyList(Criteria cri);	

	//수정
	public int updateQnaReply(QnaReplyVO qrVo);	

	//한개 선택 수정
	public QnaReplyVO getUpdateQnaReply(int replyId);	

	//삭제
	public int deleteQnaReply(QnaReplyVO qrVo);	
	
	
	
//	구버전
//	public int register(QnaReplyVO qrVo);
//	public QnaReplyVO get(int num);
//	public int modify(QnaReplyVO qrVo);
//	public List<QnaReplyVO> getList(Criteria cri, int qNum);
//	public int remove(int num);
//	public QnaReplyPageDTO getListPage(Criteria cri, int qNum);
}

package com.book45.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.book45.domain.Criteria;
import com.book45.domain.PageDTO;
import com.book45.domain.QnaReplyVO;
import com.book45.domain.QnaVO;
import com.book45.service.QnaReplyService;
import com.book45.service.QnaService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/qna/*")
@AllArgsConstructor
public class QnaController {

	@Autowired
	private QnaService service;
	
	@Autowired
	private QnaReplyService qrService;
	
	@GetMapping("/list")	//QnA 게시판리스트
	public void list(Criteria cri, Model model) {
		log.info("QnA_List==============>");
		
		model.addAttribute("list", service.getList(cri));
		
		int total = service.getTotal(cri);
		
		log.info("total : " + total);
		
		model.addAttribute("pageMaker", new PageDTO(cri, total));

	}
	@GetMapping("/register")
	public void register() {
		
	}
	
	@PostMapping("/register")	//QnA글 작성
	public String register(QnaVO qVo, RedirectAttributes rttr) {
		log.info("QnA_Register=========> " + qVo);
		service.register(qVo);
		
		rttr.addFlashAttribute("result", qVo.getNum());
		
		return "redirect:/qna/list";
	}
	
	@GetMapping({"/get", "/modify"})
	public void get(@RequestParam("num") int num, @ModelAttribute("cri") Criteria cri, Model model) {
		log.info("get or modify======>");
		model.addAttribute("qna", service.get(num));
	}

	
	@PostMapping("/modify")	//수정
	public String modify(@ModelAttribute("qVo") QnaVO qVo, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
		log.info("QnA_modify===>");
		
		if (service.modify(qVo)) {
			rttr.addFlashAttribute("result", "success");
		}
		
		return "redirect:/qna/list" + cri.getListLink();
	}
	
	@PostMapping("/remove")	//삭제
	public String remove(@RequestParam("num") int num, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
		log.info("QnA_remove==>>");
		
		if (service.remove(num)) {
			rttr.addFlashAttribute("result", "success");
		}
		
		return "redirect:/qna/list" + cri.getListLink();
	}
	
	// 답변 달기 팝업창 요청
	@GetMapping("/qnaReplyEnroll/{id}")
	public String qnaReplyEnrollWindowGET(@PathVariable("id")String id, int num, Model model) {
		
		QnaVO qna = service.getQnaTitle(num);
		
		model.addAttribute("qnaInfo", qna);
		model.addAttribute("id", id);
		
		return "/qna/qnaReplyEnroll";
	}
	                                                           
	/* 리뷰 수정 팝업창 */
	@GetMapping("/qnaReplyUpdate")
	public String replyUpdateWindowGET(QnaReplyVO qrVo, Model model) {
		QnaVO qna = service.getQnaTitle(qrVo.getQnaNum());
		model.addAttribute("qnaInfo", qna);
		model.addAttribute("qnaReplyInfo", qrService.getUpdateQnaReply(qrVo.getNum()));
		model.addAttribute("id", qrVo.getId());
		
		return "/qna/qnaReplyUpdate";
	}

	

}

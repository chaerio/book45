package com.book45.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book45.domain.Criteria;
import com.book45.domain.QnaReplyPageDTO;
import com.book45.domain.QnaReplyVO;
import com.book45.service.QnaReplyService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@RestController 
@Log4j
@RequestMapping("/qnareply")
@AllArgsConstructor // 매개변수가 있는 생성자
public class QnaReplyController {
	
	private QnaReplyService service;

	@PostMapping("/enroll")
	public void enrollQnaReplyPOST(QnaReplyVO qrVo) {
		log.info("QnaReplyVO:   "+qrVo);
		service.enrollQnaReply(qrVo);
	}
//	댓글체크 부분 주석
//	@PostMapping("/check")
//	public String replyQnaCheckPOST(QnaReplyVO qrVo) {
//		return service.checkQnaReply(qrVo);
//	}	

	@GetMapping(value="/list", produces = MediaType.APPLICATION_JSON_VALUE)
	public QnaReplyPageDTO qnaQnaReplyListPOST(Criteria cri) {
		return service.qnaReplyList(cri);
	}	

	@PostMapping("/update")
	public void replyQnaModifyPOST(QnaReplyVO qrVo) {
		service.updateQnaReply(qrVo);
	}	

	@PostMapping("/delete")
	public void replyQnaDeletePOST(QnaReplyVO qrVo) {
		service.deleteQnaReply(qrVo);
	}	
	
	
	
	
//	구버전
//	// 댓글 달기
//	@PostMapping(value="/new", consumes = "application/json", produces= MediaType.TEXT_PLAIN_VALUE)
//	public ResponseEntity<String> create(@RequestBody QnaReplyVO qrVo) {
//		log.info("QnaReplyVO:   "+qrVo);
//		int count = service.register(qrVo);
//		log.info("Reply insert count: " + count);
//		
//		
//		
//		return count == 1 ? new ResponseEntity<String>("success", HttpStatus.OK) : new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
//	}
//	
//	
//	
//	
//	@GetMapping(value="/pages/{num}/{page}", 
//			produces= {MediaType.APPLICATION_XML_VALUE, 
//						MediaType.APPLICATION_JSON_VALUE})
//	public ResponseEntity<QnaReplyPageDTO> getList(
//			@PathVariable("page") int page, 
//			@PathVariable("num") int num) {
//		
//		Criteria cri = new Criteria(page, 10);
//		return new ResponseEntity<QnaReplyPageDTO>(service.getListPage(cri, num), HttpStatus.OK);
//	}
//	
//	//댓글 삭제
//	@DeleteMapping(value="/{num}", produces= MediaType.TEXT_PLAIN_VALUE)
//	public ResponseEntity<String> remove(@PathVariable("num") int num) {
//		log.info("reply remove:  "+num);
//		return service.remove(num) == 1 ? new ResponseEntity<String>("success", HttpStatus.OK) : new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
//	}
//	
//	//댓글 한개만 조회
//	@GetMapping(value="/{num}", produces= {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
//	public ResponseEntity<QnaReplyVO> get(@PathVariable("num") int num) {
//		log.info("replyget:  "+num);
//		return new ResponseEntity<QnaReplyVO>(service.get(num), HttpStatus.OK);
//	}
//	
//	// 댓글 수정
//	@RequestMapping(method= {RequestMethod.PUT, RequestMethod.PATCH}, value="/{num}", consumes="application/json", produces= MediaType.TEXT_PLAIN_VALUE)
//	public ResponseEntity<String> modify(@RequestBody QnaReplyVO qrVo, @PathVariable("num") int num) {
//		qrVo.setNum(num);
//		log.info("reply num:  "+num);
//		log.info("replyVO: "+qrVo);
//		return service.modify(qrVo) == 1 ? new ResponseEntity<String>("success", HttpStatus.OK) : new ResponseEntity<String>(HttpStatus.INTERNAL_SERVER_ERROR);
//	}
}

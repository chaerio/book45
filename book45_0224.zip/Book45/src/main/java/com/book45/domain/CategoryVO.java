package com.book45.domain;

import lombok.Data;

@Data
public class CategoryVO {
	private int catNum;
	private String catName;
}

package com.book45.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.book45.domain.AlbumVO;
import com.book45.domain.Criteria;
import com.book45.domain.PageDTO;
import com.book45.service.AlbumService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/album/*")
@AllArgsConstructor
public class AlbumController {

	@Autowired
	private AlbumService service;
	
//	@GetMapping("/list")
//	public void list(Model model) {
//		
//		log.info("list");
//		model.addAttribute("list", service.getList());
//	}
	
	@GetMapping("/list")
	public void list(Criteria cri, Model model) {
		
		log.info("list : " +cri);
		model.addAttribute("list", service.getList(cri));
		//model.addAttribute("pageMaker", new PageDTO(cri,123));
		
		int total = service.getTotal(cri);
		
		log.info("total : " +total);
		
		model.addAttribute("pageMaker", new PageDTO(cri, total));
	}
	
	
	@GetMapping("/register")
	public void register() {}
	
	
	@PostMapping("/register")
	public String register(AlbumVO album, RedirectAttributes rttr) {
		
		log.info("register : "+album);
		
		service.register(album);
		
		rttr.addFlashAttribute("result", album.getNum());
		
		return "redirect:/album/list";
	}
	
	@GetMapping({"/get","/modify"})
	public void get(@RequestParam("num") int num, @ModelAttribute("cri") Criteria cri, Model model) {
		
		log.info("/get or /modify");
		model.addAttribute("album",service.get(num));
		
	}
	
	@PostMapping("/modify")
	public String modify(AlbumVO album, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
		
		log.info("Modify : " +album);
		
		if(service.modify(album)) {
			rttr.addFlashAttribute("result", "modify");
		}
		
		//log.info("Modify : " +album);
		return "redirect:/album/list" + cri.getListLink();
	}
	
	@PostMapping("/remove")
	public String remove(@RequestParam("productNum") Long productNum, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
		
		log.info("remove..." +productNum);
		
		if(service.remove(productNum)) {
			rttr.addFlashAttribute("result", "delete");
		}
		
		return "redirect:/album/list" +cri.getListLink();
	}
	

	
	
}

package com.book45.domain;

import java.util.Date;

import lombok.Data;


/*

CREATE TABLE QNAREPLY (
	NUM NUMBER(10)	PRIMARY KEY,
	QNUM	NUMBER(10)		 CONSTRAINT QNAREPLY_QNUM_FK REFERENCES key(num) REFERENCES QNA(NUM) ON DELETE CASCADE, -- 원 Q&A 게시글 번호
    ID	VARCHAR2(20)		 CONSTRAINT QNAREPLY_ID_FK REFERENCES key(id) references member(id) ON DELETE CASCADE,
	CONTENT	VARCHAR2(4000)	NOT NULL,
	WRITEDATE	DATE	default sysdate,
	UPDATEDATE	DATE	default sysdate
);
*/

@Data
public class QnaReplyVO {
	
	private Long num;
	private Long qNum;
	private String id;
	private String content;
	private Date writeDate;
	private Date updateDate;

}
